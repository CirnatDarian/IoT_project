from django.apps import AppConfig


class MqttControlConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mqtt_control'
